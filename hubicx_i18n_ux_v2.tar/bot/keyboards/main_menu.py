from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

from bot.i18n import t


LANGUAGE_BUTTONS = {
    "ru": "🇷🇺 Русский",
    "en": "🇬🇧 English",
    "es": "🇪🇸 Español",
    "pt": "🇵🇹 Português",
}


def main_menu_keyboard(language_code: str = "ru") -> InlineKeyboardMarkup:
    language_title = LANGUAGE_BUTTONS.get(language_code, LANGUAGE_BUTTONS["ru"])
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=t(language_code, "menu.photo"), callback_data="main:photo"), InlineKeyboardButton(text=t(language_code, "menu.video"), callback_data="main:video")],
        [InlineKeyboardButton(text=t(language_code, "menu.templates"), callback_data="main:templates"), InlineKeyboardButton(text=t(language_code, "menu.text"), callback_data="main:text")],
        [InlineKeyboardButton(text=t(language_code, "menu.balance"), callback_data="main:balance"), InlineKeyboardButton(text=t(language_code, "menu.history"), callback_data="main:history")],
        [InlineKeyboardButton(text=language_title, callback_data="main:language")],
    ])
