"use client";

import { useEffect, useMemo, useRef, useState } from "react";

export type HubicxSelectOption = string | number | { label?: string; value: string | number };

type NormalizedOption = {
  label: string;
  value: string | number;
};

export function formatOptionLabel(value: string | number): string {
  const raw = String(value);
  const labels: Record<string, string> = {
    square_hd: "Квадрат HD",
    square: "Квадрат",
    portrait_4_3: "Портрет 4:3",
    portrait_16_9: "Портрет 16:9",
    portrait: "Портрет",
    landscape_4_3: "Альбом 4:3",
    landscape_16_9: "Альбом 16:9",
    landscape: "Альбом",
    png: "PNG",
    jpeg: "JPEG",
    jpg: "JPG",
    webp: "WEBP",
  };
  if (labels[raw]) return labels[raw];
  if (/^\d+p$/.test(raw)) return raw;
  if (/^\d+k$/i.test(raw)) return raw.toUpperCase();
  return raw
    .split("_")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function normalizeOption(option: HubicxSelectOption): NormalizedOption {
  if (typeof option === "object") {
    return { value: option.value, label: option.label || formatOptionLabel(option.value) };
  }
  return { value: option, label: formatOptionLabel(option) };
}

export default function HubicxSelect({
  id,
  value,
  options,
  disabled,
  loading,
  error,
  placeholder = "Выберите значение",
  onChange,
}: {
  id?: string;
  value?: string | number;
  options: HubicxSelectOption[];
  disabled?: boolean;
  loading?: boolean;
  error?: string;
  placeholder?: string;
  onChange: (value: string | number) => void;
}) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);
  const normalizedOptions = useMemo(() => options.map(normalizeOption), [options]);
  const selected = normalizedOptions.find((option) => String(option.value) === String(value));

  useEffect(() => {
    if (!open) return;

    function handlePointerDown(event: MouseEvent | TouchEvent) {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    }

    function handleKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") setOpen(false);
    }

    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("touchstart", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("touchstart", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, [open]);

  return <div ref={rootRef} className="relative">
    <button
      id={id}
      type="button"
      className={`hubicx-input flex items-center justify-between gap-3 text-left shadow-soft-sm ${open ? "border-brand-primary ring-4 ring-brand-glow" : ""} ${error ? "border-danger/70" : ""}`}
      disabled={disabled || loading}
      aria-haspopup="listbox"
      aria-expanded={open}
      onClick={() => setOpen((next) => !next)}
    >
      <span className={selected ? "text-ink-primary" : "text-ink-muted"}>{loading ? "Загрузка..." : selected?.label || placeholder}</span>
      <span className={`text-sm text-brand-primary transition ${open ? "rotate-180" : ""}`}>⌄</span>
    </button>
    {open && <div className="absolute z-50 mt-2 max-h-72 w-full overflow-y-auto rounded-[20px] border border-[#E5EEF8] bg-white p-1 shadow-soft-md" role="listbox">
      {normalizedOptions.map((option) => {
        const isSelected = String(option.value) === String(value);
        return <button
          key={String(option.value)}
          type="button"
          className={`w-full rounded-[14px] px-4 py-3 text-left text-sm transition hover:bg-[#EAF4FF] active:bg-[#D9ECFF] ${isSelected ? "bg-[#EAF4FF] font-semibold text-[#0084F0]" : "text-ink-primary"}`}
          role="option"
          aria-selected={isSelected}
          onClick={() => {
            onChange(option.value);
            setOpen(false);
          }}
        >
          {option.label}
        </button>;
      })}
    </div>}
    {error && <p className="mt-1 text-xs font-semibold text-danger">{error}</p>}
  </div>;
}
