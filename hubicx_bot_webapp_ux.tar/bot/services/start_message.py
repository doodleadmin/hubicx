from pathlib import Path

from aiogram.exceptions import TelegramBadRequest
from aiogram.types import FSInputFile, Message
from aiogram.types import ReplyKeyboardRemove
from sqlalchemy.ext.asyncio import AsyncSession

from backend.app.db.models import User
from bot.keyboards.main_menu import main_menu_keyboard
from bot.services.menu_messages import delete_active_menu, save_active_menu


START_CAPTION = (
    "🤖 Hubicx — AI-хаб в Telegram\n\n"
    "📷 Генерация изображений\n"
    "🎬 Генерация видео\n"
    "💬 Чат с ИИ\n"
    "✍️ Тексты и промты\n\n"
    "Nano Banana, Seedance, Kling, Veo, Grok и другие AI-модели — в одном удобном боте."
)

START_IMAGE_PATH = Path("bot/assets/start.PNG")


async def remove_reply_keyboard(message: Message) -> None:
    try:
        cleanup = await message.answer("Обновляю меню...", reply_markup=ReplyKeyboardRemove())
        await message.bot.delete_message(chat_id=cleanup.chat.id, message_id=cleanup.message_id)
    except TelegramBadRequest:
        return


async def send_start_menu(message: Message, session: AsyncSession, user: User) -> Message:
    await delete_active_menu(message.bot, user)
    await remove_reply_keyboard(message)
    sent = await message.answer_photo(
        photo=FSInputFile(START_IMAGE_PATH),
        caption=START_CAPTION,
        reply_markup=main_menu_keyboard(user.language_code),
    )
    await save_active_menu(session, user, sent.chat.id, sent.message_id)
    return sent
